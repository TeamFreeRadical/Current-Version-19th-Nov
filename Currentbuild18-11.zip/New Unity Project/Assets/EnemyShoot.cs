﻿using UnityEngine;
using System.Collections;

public class EnemyShoot : MonoBehaviour {



	public Rigidbody bulletPrefab;
	public float fireRate = 0.0f;
	public float burstRate = 0.0f;
	public bool shouldBurst = false;


	public GameObject gunBarrel;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(Time.time > fireRate && shouldBurst == true && Time.time < burstRate)
		{
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(bulletPrefab, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			fireRate = Time.time + 0.25f;
		}

		if (Time.time > burstRate && shouldBurst == true)
		{
			shouldBurst = false;
			burstRate = Time.time + Random.Range(5.0F, 1.0F);
			fireRate = 0;
		}

		if (Time.time > burstRate && shouldBurst == false)
		{
			shouldBurst = true;
			burstRate = Time.time + 1.0f;
			fireRate = 0;
		}
	
	}
}
