﻿using UnityEngine;
using System.Collections;

public class ShootBullet : MonoBehaviour
{	

	public GUIText bombText;
	public int bombCount = 3;
	public Rigidbody bulletPrefab;
	public Rigidbody bulletPrefab2;
	public Rigidbody bulletPrefab3;
	public Rigidbody bulletPrefab4;
	public float fireRate = 1.0f;
	public AudioClip shootLaser; 
	public AudioClip explodeBall;
	public bool gatling = false;
	public bool missile = false;

	public GameObject gunBarrel;
	public GameObject gunBarrel2;
	//public float bulletSpeed = 0;

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		bombText.text = "BOMB X: " + bombCount;

		if(Input.GetKey("1"))
		{
			gatling = true;
			missile = false;
		}

		if(Input.GetKey ("2"))
		{
			gatling = false;
			missile = true;
		}

		if(Input.GetKey ("3"))
		{
			gatling = false;
			missile = false;
		}

		if(Input.GetMouseButton(0)&& Time.time > fireRate && missile == true)
		{

			Rigidbody bulletInstance3;
			bulletInstance3 = Instantiate(bulletPrefab3, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			

			fireRate = Time.time + 1f;
		}

		if(Input.GetMouseButton(0)&& Time.time > fireRate && gatling == true)
		{
			audio.PlayOneShot(shootLaser);
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(bulletPrefab4, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;

			audio.PlayOneShot(shootLaser);
			Rigidbody bulletInstance3;
			bulletInstance = Instantiate(bulletPrefab4, gunBarrel2.transform.position,gunBarrel2.transform.rotation) as Rigidbody;
			
			Rigidbody bulletInstance2;
			bulletInstance2 = Instantiate(bulletPrefab2, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			fireRate = Time.time + 0.08f;
		}

		if(Input.GetMouseButtonDown(0)&& Time.time > fireRate && gatling == false && missile == false)
		{
			audio.PlayOneShot(shootLaser);
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(bulletPrefab, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;

			Rigidbody bulletInstance2;
			bulletInstance2 = Instantiate(bulletPrefab2, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			fireRate = Time.time + 0.5f;
		}
	}
}
