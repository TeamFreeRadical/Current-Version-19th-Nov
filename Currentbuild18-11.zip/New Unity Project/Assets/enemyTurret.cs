﻿using UnityEngine;
using System.Collections;

public class enemyTurret : MonoBehaviour {
	public float enemyHp = 3;



	public int scoreValue;
	public GlobalGameLogic gameLogicThing;
	public float enemySpeed = 1.0f;


	public AudioClip deathSound;
	//GameObject gameLogicObject;
	// Use this for initialization
	
	
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		


		




		
		//vector between us
		
		//dist between us
		//float dist = dif.magnitude;
		
		//speed we could travel
		//float curSpeed = speed * dist * scaleRate * Time.deltaTime;
		

		//more movetowards
	}
	
	
	void OnTriggerEnter(Collider other) 
	{
		if (other.tag == "Shiggy")
		{

			enemyHp = enemyHp -1;
		}
		
		if (other.tag == "Explode")
		{
			Destroy (gameObject);
		}

		
		if (other.tag == "Player")
		{
			Destroy(other);
		}
		//enemyHp = enemyHp -1;
		
		//}
		//if (enemyHp == 0)
		//{
		//gameLogicThing.RemoveSpawn (1);
		//gameLogicThing.AddScore (scoreValue);
		//Destroy (gameObject);
		//}
		
	}
}
