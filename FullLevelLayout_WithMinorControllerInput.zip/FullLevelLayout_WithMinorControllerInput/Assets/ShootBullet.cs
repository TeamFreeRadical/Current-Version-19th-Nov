﻿using UnityEngine;
using System.Collections;

public class ShootBullet : MonoBehaviour
{	

	public GUIText bombText;
	public int bombCount = 3;
	public Rigidbody bulletPrefab;
	public Rigidbody bulletPrefab2;
	public Rigidbody bulletPrefab3;
	public float fireRate = 1.0f;
	public AudioClip shootLaser; 
	public AudioClip explodeBall;

	public GameObject gunBarrel;
	//public float bulletSpeed = 0;

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		bombText.text = "BOMB X: " + bombCount;

		if(Input.GetKey(KeyCode.P)&& Time.time > fireRate && bombCount > 0)
		{
			audio.PlayOneShot(explodeBall);
			Rigidbody bulletInstance3;
			bulletInstance3 = Instantiate(bulletPrefab3, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			fireRate = Time.time + 5.0f;
			bombCount --;
		}

		float triggerpull = Input.GetAxis ("Fire1");


		if(triggerpull <= -0.75 && Time.time > fireRate)       //Shoots using the right trigger
		{
			audio.PlayOneShot(shootLaser);
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(bulletPrefab, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;

			Rigidbody bulletInstance2;
			bulletInstance2 = Instantiate(bulletPrefab2, gunBarrel.transform.position,gunBarrel.transform.rotation) as Rigidbody;
			fireRate = Time.time + 0.5f;
		}
	}
}

// Input.GetMouseButtonDown(0)