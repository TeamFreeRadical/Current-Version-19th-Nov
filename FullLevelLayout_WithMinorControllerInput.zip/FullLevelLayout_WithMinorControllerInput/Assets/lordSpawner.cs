﻿using UnityEngine;
using System.Collections;

public class lordSpawner : MonoBehaviour 
{
	public Rigidbody enemyToSpawn;
	public GameObject spawnLocation;
	public float spawnCount;
	public float killCount;
	public GameObject lordSpawn;
	//public float spawnCount = 5;
	//public float spawnTimerMax = 10;
	//public float spawnTimer = 1;
	// Use this for initialization
	
	public GlobalGameLogic enemyLogic;
	
	void Start () 
	{
		
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		killCount = GlobalGameLogic.KillCount;
		spawnCount = GlobalGameLogic.enemyCount;

		if (killCount >= 7)
		{
			lordSpawn.SetActive(true);
			//GlobalGameLogic.enemyCount +=10;

		}
	}
}
