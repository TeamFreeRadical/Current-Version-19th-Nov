﻿using UnityEngine;
using System.Collections;

public class playerSpawn : MonoBehaviour 
{
	public GameObject playerToSpawn;
	public Rigidbody currentCrossHair;
	public GameObject shipGun;
	public GameObject shipCamera;

	// Use this for initialization
	void Start () 
	{
		Instantiate (currentCrossHair);
		Instantiate (playerToSpawn);
		Instantiate (shipGun);
		Instantiate (shipCamera);
	}
	
	// Update is called once per frame
	void Update () 
	{

	}
}
