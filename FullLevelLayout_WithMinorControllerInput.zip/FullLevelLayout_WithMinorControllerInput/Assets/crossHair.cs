﻿using UnityEngine;
using System.Collections;

public class crossHair : MonoBehaviour {

	private Vector3 mousePosition;
	//private Vector3 whatevershit;
	public float moveSpeed = 0.1f;

	public float distPlayer;
	private Transform player;
	public float noMove;

	public float spot_x;
	public float spot_y;
	public float spot_z;

	void Start ()
	{
		noMove = 15;
		player = GameObject.Find("player1_0").transform;
	}
	// Update is called once per frame
	void Update () 
	{
	// mousePosition = Input.mousePosition;
	//	mousePosition.z = 15;
	//	Vector3 mp = Camera.main.ScreenToWorldPoint (mousePosition);
	//	transform.position = mp;


		distPlayer = Vector3.Distance (this.transform.position, player.transform.position);


		if (distPlayer <= noMove) {
			float translation2 = Input.GetAxis ("Horizontal2") * moveSpeed;
			translation2 *= Time.deltaTime;
			transform.Translate (0, -translation2, 0);
			float translation3 = Input.GetAxis ("Vertical2") * moveSpeed;
			translation3 *= Time.deltaTime;
			transform.Translate (-translation3, -0, 0);
				}

		spot_x = player.transform.position.x;
		spot_y = player.transform.position.y;
		spot_z = player.transform.position.z;


		if (distPlayer >= noMove) {

			//Vector3 player.transform.position.x, player.transform.position.y, player.transform.rotation);
			transform.position = new Vector3(spot_x, spot_y, spot_z);
				}

	}
}
