﻿using UnityEngine;
using System.Collections;

public class Missile : MonoBehaviour {
	public float enemyHp = 1;
	public GameObject victim;
	public Transform lethalVertex;
	public Vector3 enemyVec;
	public int scoreValue = 2;
	public GlobalGameLogic gameLogicThing;
	public GameObject victimCollider;
	public float missileSpeed;
	
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (enemyHp == 0)
		{
			
			gameLogicThing.RemoveSpawn (1);
			gameLogicThing.AddScore (scoreValue);
			Destroy (gameObject);
		}
		
		
		Vector3 temp = victim.transform.position;
		temp.z = 0;
		
		
		Vector3 relativePos = temp - transform.position;
		relativePos.Normalize();
		Quaternion rotation = Quaternion.FromToRotation (Vector3.up, relativePos);
		
		transform.rotation = rotation;
		

		Vector3 dif = lethalVertex.position - transform.position;
		

		
		transform.position += dif.normalized * missileSpeed * Time.deltaTime;

	}

	void OnTriggerEnter(Collider other) 
	{
		if (other.tag == "Explode")
		{
			Destroy (gameObject);
		}
		if (other.tag == "Player")
		{
			Destroy(other);
		}
		if (other.tag == "Shiggy")
		{
			enemyHp = enemyHp -1;
		}
	}
}
