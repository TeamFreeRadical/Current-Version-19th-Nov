﻿using UnityEngine;
using System.Collections;

public class LordBehavior : MonoBehaviour {

	public float enemyHp = 10;
	public GameObject targetPlayer;
	public Vector3 tempVec;
	public float tempX;
	public float tempY;
	public float tempZ;
	public GlobalGameLogic gameLogicThing;
	public int lordValue = 100; 
	// Use this for initialization
	void Start () {
	
	}

	void OnTriggerEnter(Collider other) 
	{
		enemyHp = enemyHp -1;
	
		if(other.transform.name == "playerBox")
		{
				
			Destroy(other);
		}
	}

	// Update is called once per frame
	void Update () 
	{


		tempX = 0;
		tempY = 0;
		tempZ = 0;
		
		Vector3 temp = targetPlayer.transform.position;
		temp.z = 0;
		
		
		Vector3 relativePos = temp - transform.position;
		relativePos.Normalize();
		Quaternion rotation = Quaternion.FromToRotation (Vector3.up, relativePos);
		
		transform.rotation = rotation;



		if (enemyHp == 0)
		{
			gameObject.SetActive(false);
			gameLogicThing.RemoveSpawn (10);
			gameLogicThing.AddScore (lordValue);
			enemyHp = 20;
			//Destroy (gameObject);
		}

	
	}
}
