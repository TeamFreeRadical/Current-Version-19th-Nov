﻿using UnityEngine;
using System.Collections;

public class GlobalGameLogic : MonoBehaviour {
	
	public static float enemyCount;
	public static float KillCount;
	public GUIText scoreText;
	public static int score;
	public GUIText gameoverText;
	public GUIText restartText;
	private bool gameOver;
	private bool restart;
	//public int spawnCount;
	// Use this for initialization
	void Start () 
	{
		gameOver = false;
		restart = false;
		restartText.text = ("");
		gameoverText.text = ("");
		enemyCount = 0;
		score = 0;
		UpdateScore ();
	}

	public void GameOver()
	{
		gameoverText.text = "Game Over!";
		gameOver = true;
	}

	void UpdateScore ()
	{
		scoreText.text = "score: " + score;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (KillCount >= 8)
		{
			KillCount = 0;
			enemyCount = 0;
		}

		if (restart)
		{
			if (Input.GetKeyDown (KeyCode.R))
			{
				Application.LoadLevel (Application.loadedLevel);
			}
		}

		if (gameOver)
		{
			restartText.text = "Press 'R' for Restart";
			restart = true;
		}
	}

	public void AddKill (int killValue)
	{
		KillCount += killValue;
	}

	public void RemoveSpawn (int spawnValue)
	{
		enemyCount -= spawnValue;
	}

	public void AddScore (int newScoreValue)
	{
		score += newScoreValue;
		UpdateScore ();
	}
}
